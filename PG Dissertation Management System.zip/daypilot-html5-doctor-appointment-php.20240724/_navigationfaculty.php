<div class="buttons">
               
                <a href="faculty.php">faculty</a>
               
            </div>
