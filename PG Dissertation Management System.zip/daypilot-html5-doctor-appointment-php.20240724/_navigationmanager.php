<div class="buttons">
             
                <a href="manager.php">Manager</a>
            </div>
