            <div class="buttons">
                <a href="index.php">Student</a>
                <a href="faculty.php">faculty</a>
                <a href="manager.php">Manager</a>
            </div>
